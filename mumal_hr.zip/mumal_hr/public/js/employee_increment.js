// frappe.ui.form.on('Employee Increment', {
//     on_submit: function(frm) {
//         frappe.call({
//             method: 'mumal_hr.api.create_salary_structure_assignments',
//             args: {
//                 doc: frm.doc
//             },
//             callback: function(r) {
//                 if (r.message) {
//                     frappe.msgprint(r.message);
//                 }
//             }
//         });
//     }
// });
