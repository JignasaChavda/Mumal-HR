# Copyright (c) 2024, jignasha@sanskartechnolab.com and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestPerformanceTemplate(FrappeTestCase):
	pass
