// Copyright (c) 2024, jignasha@sanskartechnolab.com and contributors
// For license information, please see license.txt

frappe.ui.form.on('Self Review Form', {
	// refresh: function(frm) {

	// }
});
