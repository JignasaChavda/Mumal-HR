from frappe import _

def get_data():
	return [
		{
			"module_name": "Mumal HR",
			"type": "module",
			"label": _("Mumal HR")
		}
	]
